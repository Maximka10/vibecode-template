const fs = require("fs");
const path = require("path");

const templatePath = path.join(__dirname, "starter-template");
const outputPath = path.join(__dirname, "Projects");

// Пример данных, которые придут с формы
const clientData = {
  name: "CoffeeTime",
  templateId: "coffee-shop",
  heroTitle: "CoffeeTime — свежий кофе каждый день",
  heroSubtitle: "Онлайн-меню и доставка",
  services: [
    { title: "Меню онлайн", description: "Красивый каталог напитков" },
    { title: "Заказ столика", description: "Форма бронирования" },
    { title: "Доставка", description: "Онлайн оплата и курьер" },
  ],
};

// Создаём папку клиента
const clientFolder = path.join(outputPath, clientData.name.replace(/\s+/g, "-"));
if (!fs.existsSync(clientFolder)) fs.mkdirSync(clientFolder, { recursive: true });

// Копируем шаблон
function copyRecursive(src, dest) {
  const stats = fs.statSync(src);
  if (stats.isDirectory()) {
    if (!fs.existsSync(dest)) fs.mkdirSync(dest);
    fs.readdirSync(src).forEach((child) =>
      copyRecursive(path.join(src, child), path.join(dest, child))
    );
  } else {
    fs.copyFileSync(src, dest);
  }
}

copyRecursive(templatePath, clientFolder);

// Подставляем данные в content/about.ts
const aboutPath = path.join(clientFolder, "content/about.ts");
let aboutFile = fs.readFileSync(aboutPath, "utf8");

aboutFile = aboutFile.replace(
  /export const aboutContent = \{[\s\S]*?\};/,
  `export const aboutContent = {
  badge: "УСЛУГИ",
  title: "${clientData.heroTitle}",
  description: "${clientData.heroSubtitle}",
  services: ${JSON.stringify(clientData.services, null, 2)},
};`
);

fs.writeFileSync(aboutPath, aboutFile, "utf8");

console.log(`Проект для клиента "${clientData.name}" создан в папке: ${clientFolder}`);